import yaml
from subprocess import Popen, PIPE, run, STDOUT
from kubernetes import client as kube_client, config
import os


def get_kubeconfig_dict(kube_config=None):
    # Gets the kubeconfig as per kubectl(after applying all merging rules)
    args = ['kubectl', 'config', 'view']
    if kube_config:
        args += ["--kubeconfig", kube_config]

    # subprocess run
    proc = run(args, stdout=PIPE, stderr=STDOUT, universal_newlines=True)
    config_doc_str = proc.stdout.strip()
    config_dict = yaml.safe_load(config_doc_str)

    print(config_dict)


fn = None
# get_kubeconfig_dict()
if fn is None:
    fn = os.getenv('KUBECONFIG') if os.getenv('KUBECONFIG') else os.path.join(os.path.expanduser('~'), '.kube', 'config')

kubeconfig_node = config.kube_config._get_kube_config_loader_for_yaml_file(fn)._config

clusters = kubeconfig_node.safe_get('clusters')
for cluster in clusters:
    if cluster.safe_get('name') == "kind-kindt":
        server_address = cluster.safe_get('cluster').get('server')
        print(server_address)
