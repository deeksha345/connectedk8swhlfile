# Azure CLI Connected Kubernetes Extension #


